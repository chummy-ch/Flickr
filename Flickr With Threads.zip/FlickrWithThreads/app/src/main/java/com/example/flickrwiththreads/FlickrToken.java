package com.example.flickrwiththreads;

public class FlickrToken {
    public String token = "8a3992c54a2d4578f0e0009bdffd2f85";
    public String secret = "cb6f8a5cc321efa1";
}
